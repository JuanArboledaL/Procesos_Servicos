/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ej3recuperacion;

/**
 *
 * @author Juanito
 */
public class Ej3Recuperacion {

    public static void main(String[] args) {
        
    }
}
