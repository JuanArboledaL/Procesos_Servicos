package ejercicio1;

public abstract class Jugador {

    public int apostar(int apuesta){
        return 0;
    };

    public int ganar(int ganar) {

        return 0;
    }

    public boolean puedeSeguir() {

       return false;
    };

    @Override
    public String toString() {
        
        return "";
    };

}
